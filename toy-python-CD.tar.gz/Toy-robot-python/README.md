# Toy-robot-python

##Please see toy-robot-py for final version of code
##Test code is in Robot.py


##To run the code, have python installed and
## type > python toy-robot.py commands.txt < in the command prompt


### Thank you ! ###
